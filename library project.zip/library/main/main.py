from packs.db import f_connect, f_disconnect
from sqlite3 import Error
from tkinter import messagebox as msg
from tkinter import ttk
import tkinter as tk
from tkcalendar import DateEntry

con, cur = f_connect()


def f_line(text, char="-"):
    print((" " + text + " ").center(40, char))


class LabelStd(tk.Label):
    def __init__(self, master, r, c, text, var=None, **kwargs):
        super().__init__(master, text=text, textvariable=var, **kwargs)
        self.config(font="Calibri 12")
        self.grid(row=r, column=c, sticky="W", padx=5, pady=3)


class TextBox(tk.Entry):
    def __init__(self, owner, row, col, width=20, **kwargs):
        super().__init__(owner, **kwargs)
        self.grid(row=row, column=col, sticky="NEWS", padx=3, pady=3)
        self.config(font="Calibri 12", width=width)
        self.bind('<Enter>', self.on_start_hover)
        self.bind('<Leave>', self.on_end_hover)

    def on_start_hover(self, event):
        self.config(background="BlanchedAlmond")

    def on_end_hover(self, event):
        self.config(background="White")


class Button(tk.Button):
    def __init__(self, owner, row, col, text, command, **kwargs):
        super().__init__(owner, command=command, text=text, **kwargs)
        self.grid(row=row, column=col, sticky="NEWS", padx=2, pady=2)
        self.config(font="Calibri 12",bg="#D9EAFD")
        self.bind('<Enter>', self.on_start_hover)
        # self.bind('<Leave>', self.on_end_hover)

    def on_start_hover(self, event):
        self.config(background="LightCyan")

    # def on_end_hover(self, event):
    #     self.config(background="SystemButtonFace")


class ListBox(tk.Listbox):
    def __init__(self, owner, row, col, **kwargs):
        super().__init__(owner, **kwargs)
        self.grid(row=row, column=col, sticky="NEWS", padx=4, pady=4)
        self.config(font="Calibri 12",bg="#F4F6FF")
        self.config(exportselection=False)


class ComboBoxStd(ttk.Combobox):
    def __init__(self, master, r, c, values, var=None, **kwargs):
        super().__init__(master, values=values,textvariable=var, **kwargs)
        self["font"] = "Arial 12"
        self.grid(row=r, column=c, sticky="NEWS", padx=5, pady=3)


class Application:
    def __init__(self):
        self.frm_main = tk.Tk()
        self.frm_main.title("Library Management")
        self.frm_main.minsize(600, 180)
        self.frm_main.maxsize(780, 500)
        self.frm_main.resizable(False,False)
        self.frm_main.config(bg="#FAF6E3")
        # r("icons/python.ico")
        # self.frm_main.iconbitmap("icons\icon.ico")

        # self.image = tk.PhotoImage(file="lib.png")
        # self.header = LabelStd(self.frm_main, 0, 0, "", image=self.image, width=390, height=130)pyinstaller.exe --onefile --icon=myicon.ico main.py
        # self.header.grid(columnspan=2)
        self.create_main_buttons()

    def create_main_buttons(self):
        self.clear_frame()
        self.btn_members = Button(self.frm_main, 0, 0, "Members", self.show_members)
        self.btn_books = Button(self.frm_main, 1, 0, "Books", self.show_books)
        self.btn_loans = Button(self.frm_main, 2, 0, "Loans", self.show_loans)
        self.btn_exit = Button(self.frm_main, 3, 0, "Exit", self.exit)
        self.lst_books = ListBox(self.frm_main, 0, 1, width=80, height=20)
        self.f_list_refresh("books")
        self.lst_books.grid(rowspan=5)


    def exit(self):
        exit()

    def show_books(self):
        self.clear_frame()
        self.btn_add_book = Button(self.frm_main, 0, 0, "Add Book", self.show_add_book_form)
        self.btn_edit_book = Button(self.frm_main, 1, 0, "Edit Book", self.edit_book)
        self.btn_delete_book = Button(self.frm_main, 2, 0, "Delete Book", self.delete_book)
        self.btn_back = Button(self.frm_main, 3, 0, "Back", self.create_main_buttons)
        self.lst_books = ListBox(self.frm_main, 0, 1, width=70, height=20)
        self.f_list_refresh("books")
        self.lst_books.grid(rowspan=6, column=6)

    def show_members(self):
        self.clear_frame()
        self.btn_add_member = Button(self.frm_main, 0, 0, "Add Member", self.show_add_member_form)
        self.btn_edit_member = Button(self.frm_main, 1, 0, "Edit Member", self.edit_member)
        self.btn_delete_member = Button(self.frm_main, 2, 0, "Delete Member", self.delete_member)
        self.btn_back = Button(self.frm_main, 3, 0, "Back", self.create_main_buttons)
        self.lst_members = ListBox(self.frm_main, 0, 1, width=90, height=20)
        self.f_list_refresh("members")
        self.lst_members.grid(rowspan=6, column=6)

    def show_loans(self):
        self.clear_frame()

        self.name = tk.StringVar()
        self.b_name = tk.StringVar()
        self.returntime=tk.StringVar()
        # LabelStd(self.frm_main, 0, 0, "Select Member:")
        ComboBoxStd(self.frm_main, 0, 0, self.get_members_list(), self.name)

        # LabelStd(self.frm_main, 1, 0, "Select Book:")
        ComboBoxStd(self.frm_main, 1, 0, self.get_books_list(),self.b_name)

        date_picker = DateEntry(self.frm_main, textvariable=self.returntime,
                                date_pattern='yyyy-mm-dd', font="Calibri 12")
        date_picker.grid(row=2, column=0, sticky="NEWS", padx=3, pady=3)

        self.btn_add_loan = Button(self.frm_main, 3, 0, "Add Loan", self.add_loan)
        self.btn_delete_loan = Button(self.frm_main, 4, 0, "Delete Loan", self.show_delete_loan_form)
        # self.btn_list_loans = Button(self.frm_main, 4, 0, "List Loans", self.l)
        self.btn_back = Button(self.frm_main, 5, 0, "Back", self.create_main_buttons)

        self.lst_loans = ListBox(self.frm_main, 0, 2, width=90, height=20)
        self.f_list_refresh("loans")
        self.lst_loans.grid(rowspan=7)

    def show_add_book_form(self):
        self.clear_frame()

        LabelStd(self.frm_main, 0, 1, "Title:")
        self.txt_title = TextBox(self.frm_main, 1, 1, width=20)

        LabelStd(self.frm_main, 2, 1, "Author:")
        self.txt_author = TextBox(self.frm_main, 3, 1, width=20)

        LabelStd(self.frm_main, 4, 1, "Year:")
        self.txt_year = TextBox(self.frm_main, 5, 1, width=20)

        LabelStd(self.frm_main, 6, 1, "Genre:")
        self.txt_genre = TextBox(self.frm_main, 7, 1, width=20)


        self.btn_add_book = Button(self.frm_main, 8, 1, "Add Book", self.add_book)
        self.btn_back = Button(self.frm_main, 9, 1, "Back", self.show_books)



    def show_add_member_form(self):
        self.clear_frame()

        LabelStd(self.frm_main, 0, 1, "Name:")
        self.txt_name = TextBox(self.frm_main, 1, 1, width=20)

        LabelStd(self.frm_main, 2, 1, "Tel:")
        self.txt_tel = TextBox(self.frm_main, 3, 1, width=20)

        LabelStd(self.frm_main, 4, 1, "Disc:")
        self.txt_disc = TextBox(self.frm_main, 5, 1, width=20)

        LabelStd(self.frm_main, 6, 1, "Type:")
        self.txt_type = TextBox(self.frm_main, 7, 1, width=20)

        self.btn_add_member = Button(self.frm_main, 8, 1, "Add Member", self.add_member)
        self.btn_back = Button(self.frm_main, 9, 1, "Back", self.show_members)

    def show_delete_loan_form(self):
        self.clear_frame()

        LabelStd(self.frm_main, 0, 0, "Select Loan to Delete:")
        self.lst_loans = ListBox(self.frm_main, 0, 1, width=90, height=20)
        self.f_list_refresh("loans")

        self.btn_delete_loan = Button(self.frm_main, 1, 1, "Delete Loan", self.delete_loan)
        self.btn_back = Button(self.frm_main, 2, 1, "Back", self.show_loans)

    # def list_loans(self):
    #     self.clear_frame()
    #     self.lst_loans = ListBox(self.frm_main, 0, 0, width=90, height=20)
    #     self.btn_back = Button(self.frm_main, 1, 0, "Back", self.show_loans)
    #     self.f_list_refresh("loans")
    def add_loan(self):
        try:
            member = self.name.get()
            book = self.b_name.get()
            returnn=self.returntime.get()
            # print(f"Selected Member: {member}")
            # print(f"Selected Book: {book}")
            cur.execute("select b_title from books")
            books = [item[0] for item in cur.fetchall()]

            if len(member) > 0 and book in books and returnn:
                cur.execute(
                     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES ((SELECT member_id FROM members WHERE m_name = ?), (SELECT book_id FROM books WHERE b_title = ?), date('now'), ?)",
                    (member, book,returnn))
                con.commit()
                msg.showinfo("Success", "Loan added successfully!")
                self.f_list_refresh("loans")
            else:
                print(f"Invalid Input: Member: {member}, Book: {book}, Books: {books}")
                msg.showerror("Error", "Please select both a member and a book!")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def delete_loan(self):
        try:
            selected_item_index = self.lst_loans.curselection()
            if not selected_item_index:
                msg.showerror("Error", "Please select a loan to delete.")
                return

            selected_item = self.lst_loans.get(selected_item_index)
            member_name = selected_item.split(" borrowed ")[0]
            book_title = selected_item.split(" borrowed '")[1].split("' on")[0]

            cur.execute(
                "delete from loans where member_id = (select member_id from members where m_name = ?) and book_id = (select book_id from books where b_title = ?)",
                (member_name, book_title))
            con.commit()
            msg.showinfo("Success", "Loan deleted successfully!")
            # self.list_loans()
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def get_members_list(self):
        try:
            cur.execute("SELECT m_name FROM members")
            members = cur.fetchall()
            return [member[0] for member in members]
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")
            return []

    def get_books_list(self):
        try:
            cur.execute("SELECT b_title FROM books")
            books = cur.fetchall()
            return [book[0] for book in books]
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")
            return []

    def add_book(self):
        try:
            title = self.txt_title.get()
            author = self.txt_author.get()
            year = self.txt_year.get()
            genre = self.txt_genre.get()

            if not title or not author or not year or not genre:
                msg.showerror("Error", "Please fill all fields!")
                return

            cur.execute("insert into books (b_title, b_author, b_year, b_genre) values (?, ?, ?, ?)",
                        (title, author, year, genre))
            con.commit()
            msg.showinfo("Success", "Book added successfully!")
            self.f_list_refresh("books")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def edit_book(self):
        try:
            selected_item_index = self.lst_books.curselection()
            if not selected_item_index:
                msg.showerror("Error", "Please select a book to edit.")
                return

            selected_item = self.lst_books.get(selected_item_index)
            self.book_title = selected_item.split(" by ")[0]

            cur.execute("SELECT * FROM books WHERE b_title = ?", (self.book_title,))
            book = cur.fetchone()

            if book:
                self.show_edit_book_form(book)
            else:
                msg.showerror("Error", "Book not found.")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def show_edit_book_form(self, book):
        self.clear_frame()

        LabelStd(self.frm_main, 0, 1, "Title:")
        self.txt_title = TextBox(self.frm_main, 1, 1, width=20)
        self.txt_title.insert(0, book[0])

        LabelStd(self.frm_main, 2, 1, "Author:")
        self.txt_author = TextBox(self.frm_main, 3, 1, width=20)
        self.txt_author.insert(0, book[1])

        LabelStd(self.frm_main, 4, 1, "Year:")
        self.txt_year = TextBox(self.frm_main, 5, 1, width=20)
        self.txt_year.insert(0, book[2])

        LabelStd(self.frm_main, 6, 1, "Genre:")
        self.txt_genre = TextBox(self.frm_main, 7, 1, width=20)
        self.txt_genre.insert(0, book[3])

        self.btn_update_book = Button(self.frm_main, 8, 1, "Update Book", self.update_book)
        self.btn_back = Button(self.frm_main, 9, 1, "Back", self.show_books)

    def update_book(self):
        try:
            new_title = self.txt_title.get()
            author = self.txt_author.get()
            year = self.txt_year.get()
            genre = self.txt_genre.get()

            if not new_title or not author or not year or not genre:
                msg.showerror("Error", "Please fill all fields!")
                return

            cur.execute("UPDATE books SET b_title = ?, b_author = ?, b_year = ?, b_genre = ? WHERE b_title = ?",
                        (new_title, author, year, genre, self.book_title))
            con.commit()
            msg.showinfo("Success", "Book updated successfully!")
            self.f_list_refresh("books")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def delete_book(self):
        try:
            selected_item_index = self.lst_books.curselection()
            if not selected_item_index:
                msg.showerror("Error", "Please select a book to delete.")
                return

            selected_item = self.lst_books.get(selected_item_index)
            book_title = selected_item.split(" by ")[0]

            cur.execute("DELETE FROM books WHERE b_title = ?", (book_title,))
            con.commit()
            msg.showinfo("Success", "Book deleted successfully!")
            self.f_list_refresh("books")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def add_member(self):
        try:
            name = self.txt_name.get()
            tel = self.txt_tel.get()
            disc = self.txt_disc.get()
            member_type = self.txt_type.get()

            if not name or not tel or not disc or not member_type:
                msg.showerror("Error", "Please fill all fields!")
                return

            cur.execute("INSERT INTO members (m_name, tel, disc, type) VALUES (?, ?, ?, ?)",
                        (name, tel, disc, member_type))
            con.commit()
            msg.showinfo("Success", "Member added successfully!")
            self.f_list_refresh("members")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def edit_member(self):
        try:
            selected_item_index = self.lst_members.curselection()
            if not selected_item_index:
                msg.showerror("Error", "Please select a member to edit.")
                return

            selected_item = self.lst_members.get(selected_item_index)
            member_name = selected_item.split(",")[0]
            self.original_member_name = member_name

            cur.execute("SELECT * FROM members WHERE m_name = ?", (member_name,))
            member = cur.fetchone()

            if member:
                self.show_edit_member_form(member)
            else:
                msg.showerror("Error", "Member not found.")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def show_edit_member_form(self, member):
        self.clear_frame()

        LabelStd(self.frm_main, 0, 1, "Name:")
        self.txt_name = TextBox(self.frm_main, 1, 1, width=20)
        self.txt_name.insert(0, member[1])

        LabelStd(self.frm_main, 2, 1, "Tel:")
        self.txt_tel = TextBox(self.frm_main, 3, 1, width=20)
        self.txt_tel.insert(0, member[2])

        LabelStd(self.frm_main, 4, 1, "Disc:")
        self.txt_disc = TextBox(self.frm_main, 5, 1, width=20)
        self.txt_disc.insert(0, member[3])

        LabelStd(self.frm_main, 6, 1, "Type:")
        self.txt_type = TextBox(self.frm_main, 7, 1, width=20)
        self.txt_type.insert(0, member[4])

        self.btn_update_member = Button(self.frm_main, 8, 1, "Update Member", self.update_member)
        self.btn_back = Button(self.frm_main, 9, 1, "Back", self.show_members)

    def update_member(self):
        try:
            new_name = self.txt_name.get()
            tel = self.txt_tel.get()
            disc = self.txt_disc.get()
            member_type = self.txt_type.get()

            if not new_name or not tel or not disc or not member_type:
                msg.showerror("Error", "Please fill all fields!")
                return

            cur.execute("UPDATE members SET m_name = ?, tel = ?, disc = ?, type = ? WHERE m_name = ?",
                        (new_name, tel, disc, member_type, self.original_member_name))
            con.commit()
            msg.showinfo("Success", "Member updated successfully!")
            self.f_list_refresh("members")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def delete_member(self):
        try:
            selected_item_index = self.lst_members.curselection()
            if not selected_item_index:
                msg.showerror("Error", "Please select a member to delete.")
                return

            selected_item = self.lst_members.get(selected_item_index)
            member_name = selected_item.split(",")[0]

            cur.execute("DELETE FROM members WHERE m_name = ?", (member_name,))
            con.commit()
            msg.showinfo("Success", "Member deleted successfully!")
            self.f_list_refresh("members")
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")

    def f_list_refresh(self, list_type):
        try:
            if list_type == "books":
                cur.execute("SELECT b_title, b_author, b_year, b_genre FROM books")
                items = cur.fetchall()
                item_list = [f"{b_title} by {b_author} ({b_year}) - {b_genre}" for b_title, b_author, b_year, b_genre in
                             items]
                self.lst_books.delete(0, tk.END)
                for item in item_list:
                    self.lst_books.insert(tk.END, item)
            elif list_type == "members":
                cur.execute("SELECT m_name, tel, disc, type FROM members")
                items = cur.fetchall()
                item_list = [f"{m_name}, Tel: {tel}, Disc: {disc}, Type: {type}" for m_name, tel, disc, type in items]
                self.lst_members.delete(0, tk.END)
                for item in item_list:
                    self.lst_members.insert(tk.END, item)
            elif list_type == "loans":
                cur.execute(
                    "SELECT l.member_id, l.book_id, l.loan_date, l.return_date, m.m_name, b.b_title FROM loans l JOIN members m ON l.member_id = m.member_id JOIN books b ON l.book_id = b.book_id")
                items = cur.fetchall()
                item_list = [f"{m_name} borrowed '{b_title}' on {loan_date}, return by {return_date}" for
                             member_id, book_id, loan_date, return_date, m_name, b_title in items]
                self.lst_loans.delete(0, tk.END)
                for item in item_list:
                    self.lst_loans.insert(tk.END, item)
        except Error as e:
            msg.showerror("Error", f"Database error: {str(e)}")
    def clear_frame(self):
        for widget in self.frm_main.winfo_children():
            widget.destroy()


app = Application()
app.frm_main.mainloop()
f_disconnect(con)
