from sqlite3 import Error
import sqlite3

def f_connect():
    try:
        connection= sqlite3.connect('mydb.db')
        # print("connection created")
        cursor=connection.cursor()
        # print("cursor created!")
        return (connection,cursor)
    except Error as e:
        print(f" Error :{'DB connect':20}:{'.'.join(e.args)}")

def f_disconnect(connection):
    try:
        connection.close()
        # print("connection closed!")
    except Error as e:
        print(f" Error :{'DB disconnect':20}:{'.'.join(e.args)}")
