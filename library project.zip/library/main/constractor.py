from packs.db import f_connect, f_disconnect
from sqlite3 import Error

con, cur = f_connect()
# books_data = [
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('The Great Gatsby', 'F. Scott Fitzgerald', 1925, 'Fiction')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('1984', 'George Orwell', 1949, 'Dystopian')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('To Kill a Mockingbird', 'Harper Lee', 1960, 'Fiction')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('Pride and Prejudice', 'Jane Austen', 1813, 'Romance')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('The Catcher in the Rye', 'J.D. Salinger', 1951, 'Fiction')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('Moby-Dick', 'Herman Melville', 1851, 'Adventure')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('War and Peace', 'Leo Tolstoy', 1869, 'Historical Fiction')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('The Odyssey', 'Homer', -800, 'Epic')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('Ulysses', 'James Joyce', 1922, 'Modernist')",
#     "INSERT INTO books (b_title, b_author, b_year, b_genre) VALUES ('The Iliad', 'Homer', -750, 'Epic')"
# ]
# members_data = [
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Adriana Baldwin', '717764', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Otis Green', '951251', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Fay Mayer', '815071', -20, 'VIP')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Enid Anthony', '629306', -20, 'VIP')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Kirsten Mason', '466523', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Mauro Bowers', '837553', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Adrienne Stein', '681756', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Zackary Heath', '566671', -20, 'VIP')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Jeffry Newman', '431421', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Pat Gentry', '396031', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Liza Bradley', '749771', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Jack Benton', '663080', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Maynard Francis', '748754', -20, 'VIP')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Cherie Curtis', '647639', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Elton Duffy', '886491', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Blaine Marks', '487209', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Stacey Cervantes', '633271', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Scottie Ramsey', '719219', -20, 'VIP')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Jay Lopez', '503979', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Cornelius Summers', '808273', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Myron Gamble', '770992', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Cordell Wilkerson', '807153', -20, 'VIP')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Lee Porter', '711969', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Meagan Hayden', '688458', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Leonard Lyons', '467795', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Allie Deleon', '829903', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Kara York', '458061', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Rufus Thornton', '967656', 20, 'Tourist')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Salvador Rhodes', '779826', 0, 'Standard')",
#     "INSERT INTO members (m_name, tel, disc, type) VALUES ('Lewis Villa', '295135', -20, 'VIP')"
# ]
# loans_data = [
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (1, 1, '2023-01-10', '2023-01-20')",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (2, 2, '2023-02-05', '2023-02-15')",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (3, 3, '2023-03-12', NULL)",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (4, 4, '2023-04-20', NULL)",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (5, 5, '2023-05-01', '2023-05-11')",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (6, 6, '2023-06-07', '2023-06-17')",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (7, 7, '2023-07-14', '2023-07-24')",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (8, 8, '2023-08-22', NULL)",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (9, 9, '2023-09-05', '2023-09-15')",
#     "INSERT INTO loans (member_id, book_id, loan_date, return_date) VALUES (10, 10, '2023-10-10', NULL)"
# ]
try:
    # for d in members_data:
    #     cur.execute(d)
    # con.commit()
    # for d in books_data:
    #     cur.execute(d)
    # con.commit()
    # for d in loans_data:
    #     cur.execute(d)
    # con.commit()
    # cur.execute("create table books (book_id INTEGER PRIMARY KEY AUTOINCREMENT, b_title TEXT, b_author TEXT, b_year INTEGER, b_genre TEXT)")
    # cur.execute("create table members (member_id integer primary key autoincrement, m_name text, tel text, disc integer, type text)")
    # cur.execute("create table loans (loan_id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER, book_id INTEGER, loan_date TEXT, return_date TEXT, FOREIGN KEY (member_id) REFERENCES members(id), FOREIGN KEY (book_id) REFERENCES books(id))")
    cur.execute("select * from members")
    data = cur.fetchall()
    for d in data:
        print(d)
    print("Done!")
except Error as e:
    print(f" Error :{'DB connect':20}:{'.'.join(e.args)}")

f_disconnect(con)