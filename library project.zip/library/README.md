Library Management System

A desktop-based Library Management System built with Python, Tkinter,
and SQLite. The application provides a graphical interface for managing
a library's book catalog, member records, and book-loan records,
including loan dates and expected return dates.

 Project Overview

This project demonstrates how a small desktop application can combine a
graphical user interface with a relational database. Users can manage
books and members through separate screens, then create and review loan
records by selecting a member, a book, and an expected return date.

The application is designed for a small library or as a learning project
in Python GUI development and database operations.

 Features

 Book Management

-   View the library's book catalog.
-   Add a book with its title, author, publication year, and genre.
-   Edit an existing book's details.
-   Delete a selected book.
-   Display books in a list with their title, author, year, and genre.

Member Management

-   View registered library members.
-   Add a member with a name, telephone number, discount value, and
    membership type.
-   Edit member details.
-   Delete a selected member.
-   Display member information in a list.

Loan Management

-   Create a loan record by selecting a member and a book.
-   Record the loan date automatically using the current date.
-   Choose an expected return date with a calendar date picker.
-   View recorded loans, including the member, book, loan date, and
    expected return date.
-   Delete a selected loan record.

Database

-   Store books, members, and loans in a local SQLite database.
-   Use SQL queries to create, retrieve, update, and delete records.
-   Use parameterized SQL statements for many database operations.

 Graphical User Interface

-   Build the interface with Python's Tkinter and ttk widgets.
-   Use separate screens for the main menu, books, members, and loans.
-   Show success and error messages with dialog boxes.
-   Use `tkcalendar.DateEntry` to select dates.

 Technology Stack

-   ython --- application logic
-   Tkinter / ttk --- desktop graphical user interface
-   SQLite --- local relational database
-   tkcalendar --- calendar-based date selection

 Project Structure

``` text
Library-Management-System/
├── main.py                 # Main application and GUI
├── constractor.py          # Separate database inspection/initialization helper
├── mydb.db                 # SQLite database file
├── packs/
│   ├── __init__.py
│   └── db.py                # Database connection helpers
├── icons/
│   └── icon.ico             # Application icon asset
└── lib.png                  # Image asset
```

The archive also contains a virtual environment, PyInstaller build
artifacts, and packaged executable files. These are generated or
machine-specific files and generally should not be committed to a GitHub
source repository. The exact files you keep may differ depending on how
you organize the repository.

 Database Design

The SQLite database contains three main tables.

 `books`

Stores information about each book.

  Column       Purpose
  ------------ -----------------------------------------
  `book_id`    Primary key; uniquely identifies a book
  `b_title`    Book title
  `b_author`   Author's name
  `b_year`     Publication year
  `b_genre`    Book genre

 `members`

Stores library member information.

  Column        Purpose
  ------------- -------------------------------------------
  `member_id`   Primary key; uniquely identifies a member
  `m_name`      Member's name
  `tel`         Telephone number
  `disc`        Discount value
  `type`        Membership type

`loans`

Stores the relationship between members and borrowed books.

  Column          Purpose
  --------------- ------------------------------------------------
  `loan_id`       Primary key; uniquely identifies a loan record
  `member_id`     ID of the member associated with the loan
  `book_id`       ID of the borrowed book
  `loan_date`     Date the loan was created
  `return_date`   Expected return date selected by the user

The loan list combines information from the `loans`, `members`, and
`books` tables so that records can be displayed using member and book
names instead of only database IDs.

> **Date clarification:** In the current implementation, `loan_date` is
> set automatically to the current date, while the date selected in the
> calendar is saved as `return_date` (the expected return date). The
> application does not currently implement a separate workflow for
> confirming that a book has actually been returned.

 Requirements

-   Python 3.10 or later is recommended.
-   Tkinter (included with most standard Python installations; on some
    Linux distributions it may need to be installed separately).
-   `tkcalendar`
-   SQLite (included through Python's `sqlite3` module).

Installation and Setup

1.  Install Python if it is not already installed.

2.  Download or clone this repository.

3.  Open a terminal in the project directory.

4.  Create and activate a virtual environment (recommended).

5.  Install the external dependency:

    ``` bash
    python -m pip install tkcalendar
    ```

    `tkcalendar` depends on Babel, which pip normally installs
    automatically.

6.  Confirm that `main.py`, the `packs` folder, and the database file
    `mydb.db` are located in the expected project structure.

7.  Run the application:

    ``` bash
    python main.py
    ```

 Windows Virtual Environment Example

``` powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install tkcalendar
python main.py
```

 How to Use the Application

 1. Main Menu

Launch the program to open the main window. The menu provides access to
Members, Books, Loans, and Exit. The main screen also
displays the book catalog.

2. Manage Books

1.  Open Books.
2.  Select Add Book to enter the title, author, publication year,
    and genre.
3.  Select a book in the list before choosing Edit Book or Delete
    Book.
4.  Return to the main menu using Back.

 3. Manage Members

1.  Open Members.
2.  Select Add Member and enter the member's name, telephone number,
    discount value, and type.
3.  Select a member in the list before editing or deleting the record.
4.  Use Back to return.

 4. Register a Loan

1.  Open Loans.
2.  Choose a member from the member drop-down list.
3.  Choose a book from the book drop-down list.
4.  Select the expected return date using the calendar.
5.  Click Add Loan.
6.  Review the new record in the loan list.

 5. Delete a Loan Record

1.  Open Loans.
2.  Click Delete Loan.
3.  Select the loan record from the list.
4.  Click Delete Loan again to remove the selected record.

Deleting a loan record removes that record from the database; it is not
the same as recording a formal book-return transaction.

 Implementation Notes

-   `main.py` contains the Tkinter interface, screen navigation, input
    forms, and book/member/loan operations.
-   `packs/db.py` provides helper functions to connect to and disconnect
    from the SQLite database.
-   `mydb.db` stores the application's data.
-   `constractor.py` is a separate helper script that queries the
    database and prints member records. It is not the main GUI entry
    point.
-   Database exceptions are caught in several operations and displayed
    through message boxes.

 Current Limitations

The following are limitations of the current code and possible
directions for future improvement:

-   The application does not prevent a book from being loaned to
    multiple members at the same time.
-   There is no dedicated Return Book action or persistent
    return-status field.
-   Overdue loans are not automatically highlighted or reported.
-   Input validation could be strengthened, including checking that the
    publication year and discount are valid values and that the return
    date is not earlier than the loan date.
-   Records are selected and, in some operations, identified by
    displayed names or titles. Using database IDs internally would
    handle duplicate member names or book titles more reliably.
-   Database connection management and foreign-key constraints could be
    made more robust.
-   The database path is relative to the current working directory;
    launching the application from another directory may cause SQLite to
    open or create a different database file.
-   The existing database contains sample records. For a fresh
    installation, a clear database initialization script would make
    setup more reproducible.

 Suggested Future Enhancements

-   Track whether each book is available or currently on loan.
-   Add a proper return workflow with an actual return date and loan
    status.
-   Display overdue loans and upcoming due dates.
-   Search and filter books, members, and loan records.
-   Validate dates and numeric fields before saving.
-   Use database IDs for updates and deletions.
-   Add a database initialization script and sample-data option.
-   Improve responsive layout and accessibility.
-   Add automated tests for database operations.

 Troubleshooting

`ModuleNotFoundError: No module named 'tkcalendar'`

Install the package into the same Python environment used to run the
project:

``` bash
python -m pip install tkcalendar
```

The database appears empty or records are missing

Check that the program is running from the project directory containing
`mydb.db`. Because the database connection uses a relative path, a
different working directory can cause a separate database file to be
created.

The application cannot open a window

Confirm that Python was installed with Tkinter support. On Linux, the
Tkinter package may need to be installed through the operating system's
package manager.

 Learning Outcomes

This project provides practice with:

-   Building desktop interfaces with Tkinter.
-   Organizing Python code into modules.
-   Connecting Python applications to SQLite.
-   Writing SQL `SELECT`, `INSERT`, `UPDATE`, and `DELETE` queries.
-   Working with related tables and SQL joins.
-   Handling user input and database errors.
-   Selecting dates through a GUI calendar widget.

 License

No license is specified in the supplied project. Add a license file if
you want to define how others may use, modify, and distribute the code.

------------------------------------------------------------------------

Project type: Desktop application\
Primary language: Python\
Database: SQLite
